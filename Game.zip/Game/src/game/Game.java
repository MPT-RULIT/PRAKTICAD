package game;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;


public class Game extends JFrame 
{

private static Game game_window;
private static long last_frame_time;
private static Image background;
private static Image stalin;
private static Image star;
private static float star_left = 200;
private static float star_top = -50;
private static float star_v = 200;
private static int score = 0;

public static void main (String[] args) throws IOException
{
// Архипов И.А.
game_window = new Game();
game_window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
game_window.setLocation(200, 50);
game_window.setSize(900, 600);
game_window.setResizable(false);
last_frame_time = System.nanoTime();
GameField game_field = new GameField();

star = ImageIO.read(Game.class.getResourceAsStream("star1.png"));
background = ImageIO.read(Game.class.getResourceAsStream("background.png"));
stalin = ImageIO.read(Game.class.getResourceAsStream("stalin1.png"));

game_field.addMouseListener(new MouseAdapter() 
{
@Override
public void mousePressed(MouseEvent e) 
{
int x = e.getX();
int y = e.getY();
float star_right = star_left + star.getWidth(null);
float star_bottom = star_top + star.getHeight(null);
boolean is_star = x >= star_left && x <= star_right && y >= star_top && y <= star_bottom;
//Архипов И.А.
if (is_star) 
{
star_top = -100;
star_left = (int) (Math.random() * (game_field.getWidth() - star.getWidth(null)));
star_v = star_v + 10;
score++;
game_window.setTitle("Score: " + score); 
}
}
});
//Архипов И.А.
game_window.add(game_field);
game_window.setVisible(true);
}
private static void onRepaint(Graphics g)
{
long current_time = System.nanoTime();
float delt_time = (current_time - last_frame_time) * 0.000000001f;
last_frame_time = current_time;

star_top = star_top + star_v * delt_time;
g.drawImage(background, 0, 0, null);
g.drawImage(star, (int) star_left, (int) star_top, null);
if(star_top > game_window.getHeight()) g.drawImage(stalin, 500, 150, null);

}
//Архипов И.А.
public static class GameField extends JPanel{

@Override
protected void paintComponent(Graphics g){
super.paintComponent(g);
onRepaint(g);
repaint();
}
}
}